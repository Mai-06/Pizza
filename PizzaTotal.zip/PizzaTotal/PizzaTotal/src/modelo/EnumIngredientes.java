package modelo;

public enum EnumIngredientes {
	ANCHOAS("1","ANCHOAS"),
	MAIZ("2", "MAIZ"),
	JAMON("3", "JAMON"),
	QUESO("4", "QUESO"),
	SALCHICHA("5", "SALCHICHA"),
	PEPERONI("6", "PEPERONI"),
	CHAMPINONES("7", "CAMPI�ONES"),
	POLLO("8", "POLLO"),
	CARNE("9", "CARNE"),
	CEBOLLA("10", "CEBOLLA"),
	PIMIENTOS("11", "PIMIENTOS");	 
	
	private String codigo;
	private String ingrediente;
	
	private EnumIngredientes(String codigo, String ingrediente) {
		this.codigo = codigo;
		this.ingrediente = ingrediente;
	}
	
	public String getCodigo() {
		return codigo;
	}
	
	public String getIngrediente() {
		return ingrediente;
	}
	
	@Override
	public String toString() {
		return this.ingrediente;
	}
}
