package modelo;

public class Pizza {
	private String tamano;
	private int precio;
	
	public Pizza() {
		super();
	}
	
	public Pizza(String tamano, int precio) {		
		super();
		setTamano(tamano);
		setPrecio(precio);
	}	
	
	public void setTamano(String tamano) {
		this.tamano = tamano;
	}
	
	public void setPrecio(int precio) {
		this.precio = precio;
	}
	
	public String getTamano() {
		return tamano;
	}
	
	public int getPrecio() {
		return precio;
	}
}
